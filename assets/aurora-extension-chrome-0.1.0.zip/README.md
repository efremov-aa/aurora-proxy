# 🐱 Aurora — расширение для браузера

Тёплый туннель для Chrome и Edge: котик убирает рекламу, прячет твой IP
и держит под рукой статус подписки. Всё через твой локальный прокси Aurora.

## 🐾 Что умеет

| Фича | Как работает |
|---|---|
| 🧹 Реклама | `declarativeNetRequest`: DoubleClick, Google Ads, YouTube `/pagead/`, Taboola, Outbrain… |
| 🛡 Антитрекинг | Блок GA/GTM/Metrika/Hotjar/Criteo/Amplitude/Segment + очистка их кук раз в сутки |
| 🚫 Утечки IP | Блок WebRTC-запросов и STUN-хостов (Google/Cloudflare/Nextcloud) |
| 🇷🇺 RU-байпас | RU-домены идут напрямую: `bypassList` прокси + разрешающие DNR-правила (сид-набор обновляется с мастера) |
| 🎯 Режимы | «выкл» / «только этот сайт» / «везде» — session-правила DNR + переключение `chrome.proxy.settings` |
| 📊 Статус | Popup показывает тариф, дни, трафик, устройства, прокси, версию правил |
| 💳 Оплата | Кнопка «Оплатить продление» открывает Telegram-бот |
| 🔄 Обновление | Конфиг и версия правил подтягиваются с мастера раз в час |

## 🧩 Установка

1. Собери архив: `python build_zips.py` → `dist/aurora-extension-chrome-0.1.0.zip`
   и `dist/aurora-extension-edge-0.1.0.zip`.
2. Chrome: `chrome://extensions` → «Режим разработчика» → «Загрузить распакованное расширение»
   (или распакуй ZIP в папку). Edge: `edge://extensions` → «Режим разработчика» → «Загрузить расширение».
3. В popup вставь **ссылку подписки** вида
   `http://<сервер>:8891/sub?token=…&credential=…` — её выдаёт бот или панель Aurora.
4. Котик спросит у мастера адрес прокси, проверит подписку и включит туннель. 🐾

## 🔌 Как это устроено

- `background/service-worker.js` — спрашивает `GET /api/ext/config` (публичный маршрут
  мастера, авторизация по device-ссылке), ставит прокси `127.0.0.1:8899`, обновляет
  `bypassList` и session-правила, чистит трекерные куки по alarm.
- `rules/block.json` — реклама; `rules/privacy.json` — трекеры, WebRTC, STUN;
  `rules/ru_bypass.json` — разрешающие правила для RU-доменов;
  `rules/session.json` — заготовка под режимы.
- Правила обновляются по версии `rules_version` с мастера.

## 🐾 Ограничения (честно)

- Расширение управляет **браузером**, а не всей системой: то, что уже открыто в других
  программах, идёт мимо туннеля.
- SDP-munging в MV3 недоступен — защита IP работает через блок WebRTC/STUN хостов.
- Точный счётчик заблокированной рекламы доступен только в dev-режиме
  (`declarativeNetRequest.onRuleMatchedDebug`), в обычной установке его нет.

## 🛠 Разработка

- `python build_zips.py` — валидация `manifest.json` и `rules/*.json`, `node --check`
  для JS, сборка ZIP для Chrome и Edge.
- Офлайн-тест: `python test_extension_contract.py` — контракты manifest/DNR/popup.

🐾 Aurora — котик, который работает на тебя.
