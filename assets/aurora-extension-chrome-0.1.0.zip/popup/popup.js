/* Aurora — popup: спрашиваем у фонового помощника состояние и шлём команды. */

const MODE_TEXT = {
  off: "туннель выключен",
  site: "туннель только на одном сайте",
  global: "туннель глобально"
};

function send(action, extra) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(Object.assign({ action: action }, extra || {}), (reply) => {
      resolve(reply || { ok: false, error: "no-reply" });
    });
  });
}

function fmtBytes(value, limit) {
  const units = ["Б", "КБ", "МБ", "ГБ", "ТБ"];
  let size = Number(value || 0);
  let index = 0;
  while (size >= 1024 && index < units.length - 1) { size /= 1024; index += 1; }
  const used = size.toFixed(index ? 1 : 0) + " " + units[index];
  if (!limit) return used + " / безлимит";
  let cap = Number(limit);
  let ci = 0;
  while (cap >= 1024 && ci < units.length - 1) { cap /= 1024; ci += 1; }
  return used + " / " + cap.toFixed(ci ? 1 : 0) + " " + units[ci];
}

function leftDays(expires) {
  if (!expires) return "бессрочно";
  const ms = Number(expires) * 1000 - Date.now();
  if (ms <= 0) return "0";
  return String(Math.ceil(ms / 86400000));
}

function paint(state) {
  const config = state.config || {};
  document.getElementById("modeLabel").textContent =
    MODE_TEXT[state.mode] || MODE_TEXT.off;
  document.getElementById("linkCard").classList.toggle("hidden", Boolean(config.rules_version || config.plan));
  document.getElementById("statusCard").classList.toggle("hidden", !config.plan && !config.device_id);
  document.getElementById("linkInput").value = state.link || "";
  document.getElementById("plan").textContent = config.plan || "—";
  document.getElementById("days").textContent = leftDays(config.expires);
  document.getElementById("traffic").textContent = fmtBytes(config.used_bytes, config.limit_bytes);
  document.getElementById("devices").textContent =
    (config.device_count || 0) + " / " + (config.limit_devices || 0);
  document.getElementById("proxy").textContent =
    (state.proxyHost || "127.0.0.1") + ":" + (state.proxyPort || 8899);
  document.getElementById("rules").textContent = state.rulesVersion || "—";
  document.getElementById("siteName").textContent = state.site || "текущий";
  document.getElementById("expired").classList.toggle("hidden", !state.expired);
  document.querySelectorAll(".mode").forEach((btn) => {
    btn.classList.toggle("on", btn.dataset.mode === state.mode);
  });
  document.getElementById("blockAds").checked = state.blockAds !== false;
  document.getElementById("privacy").checked = state.privacy !== false;
}

async function load() {
  const reply = await send("getState");
  if (reply && reply.state) paint(reply.state);
}

async function withState(action, extra) {
  const reply = await send(action, extra);
  if (reply && reply.state) paint(reply.state);
  return reply;
}

document.getElementById("linkSave").addEventListener("click", async () => {
  const link = document.getElementById("linkInput").value.trim();
  const hint = document.getElementById("linkHint");
  const reply = await withState("setLink", { link: link });
  if (!reply.ok) {
    hint.textContent = "🐾 Ссылка не подошла. Нужен формат http://сервер:8891/sub?token=…&credential=…";
  } else {
    hint.textContent = "Готово! Котик на связи.";
  }
});

document.querySelectorAll(".mode").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const mode = btn.dataset.mode;
    let site = "";
    if (mode === "site") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      site = tab ? new URL(tab.url).hostname : "";
    }
    await withState("setMode", { mode: mode, site: site });
  });
});

document.getElementById("refresh").addEventListener("click", () => withState("refresh"));
document.getElementById("clean").addEventListener("click", () => withState("cleanTrackers"));
document.getElementById("buy").addEventListener("click", () => send("buy"));
document.getElementById("blockAds").addEventListener("change", (ev) =>
  withState("setFlags", { blockAds: ev.target.checked }));
document.getElementById("privacy").addEventListener("change", (ev) =>
  withState("setFlags", { privacy: ev.target.checked }));

load();
