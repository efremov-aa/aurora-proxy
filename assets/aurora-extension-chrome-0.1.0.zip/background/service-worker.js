/* Aurora — фоновый помощник расширения.
 * Задачи: спросить у мастера адрес прокси и статус подписки, включить/выключить
 * туннель, обновить правила, вычистить трекерные куки.
 */

const DEFAULTS = {
  link: "",
  mode: "off",
  site: "",
  blockAds: true,
  privacy: true,
  config: null,
  rulesVersion: "",
  expired: false,
  buyUrl: "",
  lastSync: 0,
  proxyHost: "127.0.0.1",
  proxyPort: 8899,
  ruBypass: []
};

const TRACKER_DOMAINS = [
  "google-analytics.com", "googletagmanager.com", "doubleclick.net",
  "hotjar.com", "mc.yandex.ru", "scorecardresearch.com", "criteo.com",
  "connect.facebook.net", "amplitude.com", "segment.io"
];

const RULESETS_AD = ["aurora_block", "aurora_ru"];
const RULESETS_PRIVACY = ["aurora_privacy", "aurora_ru"];

const ALARM_SYNC = "aurora-sync";
const ALARM_CLEAN = "aurora-clean";

function now() { return Date.now(); }

async function getState() {
  const stored = await chrome.storage.local.get(DEFAULTS);
  return Object.assign({}, DEFAULTS, stored || {});
}

async function setState(patch) {
  await chrome.storage.local.set(patch);
}

function parseLink(link) {
  try {
    const url = new URL(link);
    const token = url.searchParams.get("token") || "";
    const credential = url.searchParams.get("credential") || "";
    if (!token) return null;
    return {
      base: url.origin,
      path: url.pathname.replace(/\/+$/, ""),
      token: token,
      credential: credential
    };
  } catch (err) {
    return null;
  }
}

async function fetchConfig() {
  const state = await getState();
  const parsed = parseLink(state.link || "");
  if (!parsed) return { ok: false, error: "no-link" };
  const query = "token=" + encodeURIComponent(parsed.token) +
    "&credential=" + encodeURIComponent(parsed.credential);
  const url = parsed.base + "/api/ext/config?" + query;
  try {
    const response = await fetch(url, { method: "GET", cache: "no-store" });
    let payload = {};
    try { payload = await response.json(); } catch (err) { payload = {}; }
    if (!response.ok) {
      await setState({
        expired: response.status === 403 || response.status === 410,
        buyUrl: payload.buy_url || state.buyUrl || "",
        lastSync: now()
      });
      return { ok: false, status: response.status, error: payload.error || "http" };
    }
    const proxy = payload.proxy || {};
    const patch = {
      config: payload,
      expired: false,
      buyUrl: payload.buy_url || "",
      lastSync: now(),
      rulesVersion: payload.rules_version || "",
      proxyHost: proxy.host || state.proxyHost,
      proxyPort: proxy.port || state.proxyPort
    };
    if (Array.isArray(payload.ru_bypass) && payload.ru_bypass.length) {
      patch.ruBypass = payload.ru_bypass.slice(0, 5000);
    }
    if (Array.isArray(payload.blocked) && payload.blocked.length) {
      patch.serverBlocked = payload.blocked.slice(0, 2000);
    }
    await setState(patch);
    return { ok: true, config: payload };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

function bypassList(state) {
  const list = [];
  (state.serverBlocked || []).forEach((host) => { list.push(host); });
  (state.ruBypass || []).forEach((host) => { list.push(host); });
  if (state.mode === "site" && state.site) {
    list.push(state.site);
    const parts = String(state.site).split(".");
    if (parts.length > 2) list.push(parts.slice(1).join("."));
  }
  return list.filter((row) => typeof row === "string" && row.trim().length > 1);
}

async function setRulesets(enabled) {
  try {
    await chrome.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: enabled ? RULESETS_AD.concat(RULESETS_PRIVACY) : [],
      disableRulesetIds: enabled ? [] : RULESETS_AD.concat(RULESETS_PRIVACY)
    });
  } catch (err) {
    // набор может отсутствовать — не роняем popup
  }
}

async function setSessionRules(mode, site) {
  const rules = [];
  if (mode === "site" && site) {
    rules.push({
      id: 900001,
      priority: 1,
      action: { type: "allow" },
      condition: { requestDomains: [String(site).replace(/^[*.]+/, "")] }
    });
    rules.push({
      id: 900002,
      priority: 2,
      action: { type: "block" },
      condition: { excludedRequestDomains: [String(site).replace(/^[*.]+/, "")] }
    });
  }
  try {
    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: [900001, 900002],
      addRules: rules
    });
  } catch (err) {
    // пустое правило без условий Chrome не примет — это ожидаемо для mode != site
  }
}

async function applyProxy() {
  const state = await getState();
  const mode = state.mode || "off";
  if (mode === "off" || state.expired) {
    await chrome.proxy.settings.clear({});
    await setSessionRules("off", "");
    await setRulesets(false);
    return { mode: "off" };
  }
  const server = state.proxyHost + ":" + state.proxyPort;
  await chrome.proxy.settings.set({
    value: {
      proxyType: "fixed_servers",
      proxyServer: server,
      proxyBypassList: bypassList(state)
    },
    scope: "regular"
  });
  if (mode === "site") {
    await setSessionRules("site", state.site);
    await setRulesets(false);
  } else {
    await setSessionRules("global", "");
    await setRulesets(true);
  }
  return { mode: mode, server: server };
}

async function cleanTrackers() {
  let removed = 0;
  for (const domain of TRACKER_DOMAINS) {
    try {
      const cookies = await chrome.cookies.getAll({ domain: domain });
      for (const cookie of cookies || []) {
        const url = (cookie.secure ? "https://" : "http://") + cookie.domain.replace(/^\./, "") + cookie.path;
        await chrome.cookies.remove({ url: url, name: cookie.name, storeId: cookie.storeId });
        removed += 1;
      }
    } catch (err) {
      continue;
    }
  }
  return removed;
}

async function fullRefresh() {
  const result = await fetchConfig();
  await applyProxy();
  return result;
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(ALARM_SYNC, { periodInMinutes: 60 });
  await chrome.alarms.create(ALARM_CLEAN, { periodInMinutes: 1440 });
  await fullRefresh();
});

chrome.runtime.onStartup.addListener(async () => {
  await fullRefresh();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_SYNC) {
    await fullRefresh();
  } else if (alarm.name === ALARM_CLEAN) {
    const state = await getState();
    if (state.privacy) await cleanTrackers();
  }
});

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  const action = (message && message.action) || "";
  (async () => {
    if (action === "getState") {
      respond({ ok: true, state: await getState() });
      return;
    }
    if (action === "setLink") {
      await setState({ link: String(message.link || "").trim(), mode: "off" });
      const parsed = parseLink(String(message.link || "").trim());
      if (!parsed) {
        respond({ ok: false, error: "bad-link" });
        return;
      }
      const result = await fullRefresh();
      respond({ ok: true, result: result, state: await getState() });
      return;
    }
    if (action === "setMode") {
      await setState({
        mode: String(message.mode || "off"),
        site: String(message.site || "").replace(/^https?:\/\//, "").split("/")[0]
      });
      const applied = await applyProxy();
      respond({ ok: true, applied: applied, state: await getState() });
      return;
    }
    if (action === "refresh") {
      const result = await fullRefresh();
      respond({ ok: true, result: result, state: await getState() });
      return;
    }
    if (action === "setFlags") {
      const patch = {};
      if (typeof message.blockAds === "boolean") patch.blockAds = message.blockAds;
      if (typeof message.privacy === "boolean") patch.privacy = message.privacy;
      await setState(patch);
      await applyProxy();
      respond({ ok: true, state: await getState() });
      return;
    }
    if (action === "cleanTrackers") {
      respond({ ok: true, removed: await cleanTrackers() });
      return;
    }
    if (action === "buy") {
      const state = await getState();
      const url = state.buyUrl || state.config && state.config.buy_url || "";
      if (url) chrome.tabs.create({ url: url });
      respond({ ok: Boolean(url), url: url });
      return;
    }
    respond({ ok: false, error: "unknown" });
  })();
  return true;
});

self.addEventListener("activate", () => {
  fullRefresh();
});
